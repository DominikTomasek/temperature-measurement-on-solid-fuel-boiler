#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <Hash.h>
#include <FS.h>
#include <max6675.h>
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>



int SO = D7;
int CS = D8;
int sck = D5;

MAX6675 module(sck, CS, SO);

void Pripojse();
void podrzteplotarequest();
void podrzrootrequest();


const char* ssid = "********";
const char* password = "*******";



ESP8266WebServer server(80);

void setup() {
Serial.begin(115200);
Pripojse();



server.on("/teplota",HTTP_GET,podrzteplotarequest);
server.on("/",HTTP_GET, podrzrootrequest);

MDNS.addService("http", "tcp", 80);

server.begin();

 
}
void loop() {
  MDNS.update();
  server.handleClient();
}


void Pripojse()
{
  WiFi.begin(ssid,password);
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");

  }
  

  Serial.print(" teplotu si přečteš na této adrese 'http://");
  Serial.print(WiFi.localIP());
  Serial.println("' na připojení");

if(!MDNS.begin("teplotanakotli")){
  Serial.println("ERROR při naastavení mDNS");
}
else{
  Serial.println("mDNS se spustil");
  Serial.println("připoj se na :http://teplotanakotli.local/");
}

}

void podrzteplotarequest()
{
  float teplota = module.readCelsius();
  server.send(200, "text/plain", String(teplota));
  
}

void podrzrootrequest()
{
  String html = "<html><body>";
  html += "<h1>Teplotni graf</h1>";
  html += "<canvas id='teplotnigraf' width='800' height='400'></canvas>";
  html += "<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>";
  html += "<script>";
  html += "var ctx = document.getElementById('teplotnigraf').getContext('2d');";
  html += "var chart = new Chart(ctx, {";
  html += "type: 'line',";
  html += "data: {";
  html += "labels: [],";
  html += "datasets: [{";
  html += "label: 'Teplota (°C)',";
  html += "borderColor: 'rgb(75, 192, 192)',";
  html += "data: [],";
  html += "fill: false";
  html += "}]";
  html += "},";
  html += "options: {";
  html += "responsive: true,";
  html += "scales: {";
  html += "xAxes: [{";
  html += "display: true";
  html += "}],";
  html += "yAxes: [{";
  html += "display: true";
  html += "}]";
  html += "}";
  html += "}";
  html += "});";
  html += "setInterval(function() {";
  html += "fetch('/teplota').then(function(response) {";
  html += "response.text().then(function(data) {";
  html += "var time = new Date().toLocaleTimeString();";
  html += "chart.data.labels.push(time);";
  html += "chart.data.datasets[0].data.push(parseFloat(data));";
  html += "chart.update();";
  html += "});";
  html += "});";
  html += "}, 5000);";
  html += "</script>";
  html += "</body></html>";

  server.send(200,"text/html", html);
}

  
